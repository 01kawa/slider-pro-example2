<?php defined('C5_EXECUTE') or die("Access Denied.");
$navigationTypeText = ($navigationType == 0) ? 'arrows' : 'pages';
$c = Page::getCurrentPage();
if ($c->isEditMode()) {
    ?>
    <div class="ccm-edit-mode-disabled-item" style="<?php echo isset($width) ? "width: $width;" : '' ?><?php echo isset($height) ? "height: $height;" : '' ?>">
        <i style="font-size:40px; margin-bottom:20px; display:block;" class="fa fa-picture-o" aria-hidden="true"></i>
        <div style="padding: 40px 0px 40px 0px"><?php echo t('Image Slider disabled in edit mode.')?>
			<div style="margin-top: 15px; font-size:9px;">
				<i class="fa fa-circle" aria-hidden="true"></i>
				<?php if (count($rows) > 0) { ?>
					<?php foreach (array_slice($rows, 1) as $row) { ?>
						<i class="fa fa-circle-thin" aria-hidden="true"></i>
						<?php }
					}
				?>
			</div>
        </div>
    </div>
<?php
} else {
    ?>
<script>
$(document).ready(function() {
    $( '#example2' ).sliderPro({
        <?php if ($navigationType == 0) {?>
            arrows:true,
            buttons: false,
        <?php
        }elseif($navigationType == 1) {?> 
            arrows:false,
            buttons: true,
        <?php }elseif($navigationType == 2) {?>
            arrows:true,
            buttons: true,
        <?php }else{?>
            arrows:false,
            buttons: false,
        <?php }?>
        <?php if ($noAnimate) { echo "autoplay:false,"; } ?>
        <?php if ($timeout) { echo "autoplayDelay :$timeout,"; } ?>
        <?php if ($speed) { echo "fadeDuration:$speed,"; } ?>
        <?php if (!$pause) { echo "autoplayOnHover:stop,"; } ?>
        width: 300,
        height: 300,
        responsive: true,
        visibleSize: '100%',
    });

    // instantiate fancybox when a link is clicked
    $( ".slider-pro" ).each(function(){
        var slider = $( this );

        slider.find( ".sp-image" ).parent( "a" ).on( "click", function( event ) {
            event.preventDefault();
        
            if ( slider.hasClass( "sp-swiping" ) === false ) {
                var sliderInstance = slider.data( "sliderPro" ),
                    isAutoplay = sliderInstance.settings.autoplay;

                $.fancybox.open( slider.find( ".sp-image" ).parent( "a" ), {
                    index: $( this ).parents( ".sp-slide" ).index(),
                    afterShow: function() {
                        if ( isAutoplay === true ) {
                            sliderInstance.settings.autoplay = false;
                            sliderInstance.stopAutoplay();
                        }
                    },
                    afterClose: function() {
                        if ( isAutoplay === true ) {
                            sliderInstance.settings.autoplay = true;
                            sliderInstance.startAutoplay();
                        }
                    }
                        
                });
            }
        });
    });
});
</script>

<div id="sliderpro" <?php if ($maxWidth) {
            echo 'style="width:';
            echo $maxWidth;
            echo 'px"'; } ?>>
    
    <div id="example2" class="slider-pro <?php echo $navigationTypeText?>" >
    

    <?php if (count($rows) > 0) {
    ?>
    <div class="sp-slides" id="ccm-image-slider-<?php echo $bID ?>">

            <?php foreach ($rows as $row) {
    ?>
                <div class="sp-slide">
                <?php if ($row['linkURL']) {
    ?>
                    <a href="<?php echo $row['linkURL'] ?>" class="mega-link-overlay"></a>
                <?php
}
    ?>
                <?php
                $f = File::getByID($row['fID'])
                ?>
                <?php if (is_object($f)) {
                $tag = Core::make('html/image', array($f, false))->getTag();
                if ($row['title']) {
                    $tag->alt($row['title']);
                } else {
                    $tag->alt("slide");
                }
                $tag->addClass('sp-image');
                echo $tag;
                ?>
                <?php
}
    ?>
                <div class="sp-caption">
                    <?php if ($row['title']) {
    ?>
                    	<h2 class="ccm-image-slider-title"><?php echo $row['title'] ?></h2>
                    <?php
}
    ?>
                    <?php echo $row['description'] ?>
                </div>
                </div>
            <?php
}
    ?>

    </div>
        <?php
} else {
    ?>
        <div class="ccm-image-slider-placeholder">
            <p><?php echo t('No Slides Entered.');
    ?></p>
        </div>
        <?php
}
    ?>
</div>
</div>
<?php
} ?>




